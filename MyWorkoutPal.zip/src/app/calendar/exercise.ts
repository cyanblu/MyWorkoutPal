export interface Exercise {
    workoutName: String,
    sets: number[],
    date: Date
}
